from .scraper import scrape_insultes
from .scraper import detect_insultes
from .scraper import get_definition_insulte